﻿VIJAYAWADA LAND-USE TRAINING DATASET
===================================

Study area: Vijayawada
Years: 2015, 2020, 2025
CRS: EPSG:4326

FEATURES
--------
NDVI: Normalized Difference Vegetation Index
NDBI: Normalized Difference Built-up Index
NDWI: Normalized Difference Water Index

CLASS MAPPING
-------------
0 = Background / Unclassified (excluded from CSV)
1 = Water
2 = Urban
3 = Soil
4 = Vegetation

FILES
-----
Labels_2015_Aligned.tif
Labels_2020_Aligned.tif
Labels_2025_Aligned.tif
Training_Samples.csv
Class_Count_Report.csv

TRAINING CSV COLUMNS
--------------------
year, row, col, longitude, latitude,
NDVI, NDBI, NDWI, class_id, class_name

SAMPLE COUNTS
-------------
2015: 348549
2020: 344072
2025: 263513
Total: 956134

NOTES
-----
The aligned labels match the 693 x 669 index grids.
Only finite index values and classes 1-4 are included.
Class balance should be considered during model training.
Labels have not been independently verified as ground truth.
The CSV contains index features, not all raw Landsat bands.
Use spatially separated training and test regions when possible.

Prepared for the Vijayawada land-use classification project.
